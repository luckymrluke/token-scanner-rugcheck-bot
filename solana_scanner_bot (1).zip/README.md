# Solana Token Scanner + RugCheck Bot

This bot scans new Solana tokens and checks them for safety.

## How to Use
1. Install requirements
2. Add your `.env`
3. Run `main.py`
